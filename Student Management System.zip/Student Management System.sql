create database student_management_system;
use  student_management_system;

create table stud_data(studID int ,  studfNAME varchar(20), studlname varchar(20), city varchar(20), AGE int, PHONE_NO int, primary key(studID));
create table course(courseId int ,coursename varchar(20),duration varchar(20),studID int,primary key(courseId),foreign key(studID) references  stud_data(studID));
create table feedback(feedbackId int,rating varchar(20),feedbacktext varchar(200),studID int,courseId int,primary key(feedbackId),foreign key(studID) references stud_data(studID),foreign key(courseId) references course(courseId));
create table department(departmentId int,departmentname varchar(20),primary key(departmentId));
create table instructor(instructorId int,departmentId int,instructorname varchar(20),email varchar(20),contact int(10),address varchar(20),primary key(instructorid),foreign key(departmentId) references department(departmentId));

 
